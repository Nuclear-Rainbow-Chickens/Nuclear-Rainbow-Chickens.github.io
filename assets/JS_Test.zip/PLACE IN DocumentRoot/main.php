<?php
	//ie useragent = "Mozilla/5.0 (Windows NT 6.3; Trident/7.0; .NET4.0E; .NET4.0C; rv:11.0) like Gecko"
	//chrome useragent = "Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36"
	//safari useragent = "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/534.57.2 (KHTML, like Gecko) Version/5.1.7 Safari/534.57.2"
	//opera useragent = "Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.122 Safari/537.36 OPR/24.0.1558.64"
	//firefox useragent = "Mozilla/5.0 (Windows NT 6.3; rv:32.0) Gecko/20100101 Firefox/32.0"
	date_default_timezone_set('America/Los_Angeles');
	$browser = "";
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$hasTrident = strpos($useragent, "Trident");
	$hasChrome = strpos($useragent, "Chrome");
	$hasOpr = strpos($useragent, "OPR");
	$hasFirefox = strpos($useragent, "Firefox");
	$hasSafari = strpos($useragent, "Safari");
	echo "<p>User Agent: ".$useragent."</p>";
	echo "<p>Trident: ".$hasTrident."</p>";
	echo "<p>Chrome: ".$hasChrome."</p>";
	echo "<p>Opera: ".$hasOpr."</p>";
	echo "<p>Firefox: ".$hasFirefox."</p>";
	echo "<p>Safari: ".$hasSafari."</p>";
	echo "<script src=\"main.js\" type=\"text/javascript\"></script>";
	if($hasTrident !== false) {
		echo "IE";
		$browser = "IE";
	}
	else if($hasOpr !== false) {
		echo "Opera";
		$browser = "Opera";
	}
	else if($hasFirefox !== false) {
		echo "Firefox";
		$browser = "Firefox";
	}
	else if($hasSafari !== false && $hasChrome === false) {
		echo "Safari";
		$browser = "Safari";
	}
	else if($hasChrome !== false) {
		echo "<p>Chrome</p>";
		$browser = "Chrome";
	}
	$startnum = $_REQUEST['startnum'];
	$computenum = $_REQUEST['compnum'];
	$objnum = $_REQUEST['objnum'];
	$finishnum = $_REQUEST['finishnum'];
	if($startnum !== $finishnum) {
		if(floatval($finishnum) - floatval($startnum) > 0) {
			WriteResults();
		}
		else {
			echo "<script>alert('Negative Time Retake Test')</script>";
		}
	}
	function WriteResults() {

		global $browser, $startnum, $finishnum, $objnum, $computenum;
		$browserfile = "";
		$newline = "\n<test><date>";
		$newline .= date("Y/m/d--h:i:sa")."</date><browser>";
		if($browser == "Chrome") {
			$newline .= "Chrome";
			$browserfile = "chrome_results.xml";
		}
		if($browser == "IE") {
			$newline .= "Internet Explorer";
			$browserfile = "ie_results.xml";
		}
		if($browser == "Opera") {
			$newline .= "Opera";
			$browserfile = "opera_results.xml";
		}
		if($browser == "Firefox") {
			$newline .= "Firefox";
			$browserfile = "firefox_results.xml";
		}
		if($browser == "Safari") {
			$newline .= "Safari";
			$browserfile = "safari_results.xml";
		}
		$newline .= "</browser>";
		$comptime = floatval($computenum) - floatval($startnum);
		$objtime = floatval($objnum) - floatval($computenum);
		$totaltest = floatval($finishnum) - floatval($startnum);
		$newline .= "<computetime>".$comptime."</computetime>"."<objecttime>".$objtime."</objecttime>"."<totaltime>".$totaltest."</totaltime>";
		$newline.="</test>";
		$file = file($browserfile);
		array_splice($file, 2, 0,array($newline)); 
		file_put_contents($browserfile,$file);
		$filestr = file_get_contents($browserfile);
		fclose($browserfile);
		$tests = preg_match_all("/test/",$filestr) / 2;
		echo "<br><h1>Currently ".$tests." Stored</h1>";
		echo "<a id=\"link\" href=\"http://10.0.2.2\">Next Test?</a>";
		if($tests < 50) {
			echo "<script type=\"text/javascript\">document.getElementById('link').click()</script>";
		}
	}
	
	
?>