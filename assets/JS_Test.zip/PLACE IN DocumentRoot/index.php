<!DOCTYPE html>
<html>
	<head>
		<script src="main.js" type="text/javascript"></script>
	</head>
	<body onload = "Begin()">
		<?php
			include "http://192.168.1.127/main.php";
		?>
		<form style="visible: none;" id="form" action="main.php" method="post">
			start <input type="text" id="startbox" name="startnum" value="<?php echo microtime(true);?>" />
			comp <input type="text" id="compbox" name="compnum" />
			object <input type="text" id="objbox" name="objnum" />
			end <input type="text" id="finishbox" name="finishnum"/>
			<input type="submit" value="submit" />
		</form>
		
	</body>
</html>