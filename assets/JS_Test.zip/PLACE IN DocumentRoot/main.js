function Begin() {
    console.groupCollapsed("<|||||||||||||TEST||||||||||||>");
	Compute();
    console.log("COMPUTE TEST FINISHED");
	Garbage();
	console.log("GARBAGE TEST FINISHED");
	document.getElementById("finishbox").value = ((new Date().getTime()) / 1000);
	document.getElementById("form").submit();
	console.groupEnd();
}

function End() {
	console.log("WRITTEN");
}

//basic computation test
function Compute() {
	Float();
	console.log ("- finished float test");
	SortArray();
	console.log ("- finished array sort");
	Prime();
	console.log ("- finished prime sieve");
	Pi();
	console.log ("- finished calculating pi");
	Array();
	console.log ("- finished array calculations");
	document.getElementById("compbox").value = ((new Date().getTime()) / 1000);
	console.log("Computation Finished");
}

//test garbage object collecting
function Garbage() {
	Spawn();
	console.log ("- finished spawn test");
	CreateAndDestroy();
	console.log ("- finished create / destroy test");
	document.getElementById("objbox").value = ((new Date().getTime()) / 1000);
	console.log("Object Testing Finished");
}

/*<!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!>
<----------BEGIN CPU TESTING------------>
<!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!>*/

//float measurements
function Float() {
	var a = Math.random();
	a += 5.29808451-774-324-8041-74-67713773247016340160932749871094790;
	a *= 1.57654751342434134241257143638713744223147346234223345153287345531473;
	a *= 88234453221364321626383463;
	a += 68975687867587357.43252734;
	a /= 76432432453523.3;
}

//concat measurements
function StringJoin() {
	var TestString = "";
	for(var i = 0; i < 1999; i++) {
		TestString += "H";
	}
}

//factorial a big number
function Factorial(x) {
	if(x != 1) {
		return x * Factorial(x-1);
	}
	else {
		return 1;
	}
}

//sort an array
function SortArray() {
	var ar = [];
	for(var i = 0; i < 1e4; i++) {
		ar.push(Math.random() * 100);
	}
	for(var i = 0; i < ar.length; i++) {
		for(var j = (i+1); j < ar.length; j++) {
			if(ar[j-1] > ar[j]) {
				var temp = ar[j];
				ar[j] = ar[j-1];
				ar[j-1] = temp;
			}
		}
	}
}

//find primes
function Prime() {
	var arr = [];
	//assign
	for(var i = 0; i <= 1999; i++) {
		arr[i] = i;
	}
	for(var i = 2; i < arr.length; i++) {
		for(var j = i+1; j < arr.length; j++) {
			if(arr[j] % arr[i] == 0) {
				arr.splice(j, 1);
			}
		}
	}
}

//find digits of pi
function Pi() {
    var p=0;
    var n=1;
    for (i=0;i<=1e8;i++)
    {
        p=p+(4/n)-(4/(n+2));
        n=n+4;
    }
}

function Array() {
    var arr = [];
    for (var i = 0; i < 1e6; i++) {
        arr[i] = Math.random();
    }
    arr.reverse();
    arr.sort();
}
        
/*<!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!>
<-------BEGIN OBJECT CREATION/DESTRUCTION TESTING------>
<!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/

//model object
function car(speed, mph, cost) {
		this.speed = speed;
		this.mph = mph;
		this.cost = cost;
}
//create a bunch of objects that will never be needed
function Spawn() {
	var arr = [];
	for(var i = 0; i < 1e5; i++) {
		var temp = new car(5,5,5);
		arr.push(temp);
	}
	Factorial(arr[0].mph);
}

function CreateAndDestroy() {
	var arr = [];
	for(var i = 0; i < 1e2; i++) {
		var temp = new car(1,1,1);
		arr.push(temp);
	}
	for(var i = 0; i < 1e3; i++) {
		var tempb = new car(5,5,5);
		arr.push(tempb);
	}
	var b = arr[1];
}